import java.time.YearMonth;

final class Main {
    public static void main(final String[] args) {
        TestIsLeapYear();
        TestValidDate();
    }

    private static void TestValidDate() {
        final int[][] inputs = {
                { 2020, 0, 99 },
                { 2020, 13, 99 },
                { 2020, 1, 0 },
                { 2019, 2, 29 },
                { 2020, 2, 29 }
        };
        for (final int[] input : inputs) {
            final short year = (short) input[0];
            final byte month = (byte) input[1], day = (byte) input[2];
            System.out.printf("isValidDate: year %d, month %d, day %d, result: %s%n", year, month, day,
                              isValidDate(year, month, day));
        }
    }

    private static void TestIsLeapYear() {
        final int[] inputs = { 10001, 9999, 6100, 4000, 2019, 2020 };
        for (final int input : inputs) {
            System.out.printf("isLeapYear: %d, result: %s%n", input, isLeapYear(input));
        }
    }

    private static boolean isLeapYear(final int year) {
        if (year > 10000 || year < 1000) {
            return false;
        }
        if (year % 100 == 0) {
            return year % 400 == 0;
        } else {
            return year % 4 == 0;
        }
    }

    private static boolean isValidDate(final short year, final byte month, final byte day) {
        if (month >= 1 && month <= 12) {
            if (day >= 1) {
                return day <= YearMonth.of(year, month).lengthOfMonth();
            }
        }
        return false;
    }
}
