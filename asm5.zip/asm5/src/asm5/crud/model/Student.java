package asm5.crud.model;

import java.time.LocalDate;

public class Student {
    private final Integer id;
    private String name;
    private LocalDate birthday;
    private Boolean sex;
    private Float gpa;
    private String grade;

    public Student(final Integer id,
                   final String name,
                   final LocalDate birthday,
                   final Boolean sex,
                   final Float gpa,
                   final String grade) {
        this.id = id;
        this.name = name;
        this.birthday = birthday;
        this.sex = sex;
        this.gpa = gpa;
        this.grade = grade;
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public LocalDate getBirthday() {
        return birthday;
    }

    public void setBirthday(final LocalDate birthday) {
        this.birthday = birthday;
    }

    public Boolean getSex() {
        return sex;
    }

    public void setSex(final Boolean sex) {
        this.sex = sex;
    }

    public Float getGpa() {
        return gpa;
    }

    public void setGpa(final Float gpa) {
        this.gpa = gpa;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(final String grade) {
        this.grade = grade;
    }
}
