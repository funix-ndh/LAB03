package asm5.crud.businessLayer;

import java.time.LocalDate;
import java.util.List;

import asm5.crud.dataAccessLayer.DataAccessLayer;
import asm5.crud.model.Student;

public class BusinessLayer {
    private final DataAccessLayer dataAccessLayer;

    public BusinessLayer(final DataAccessLayer dataAccessLayer) {this.dataAccessLayer = dataAccessLayer;}

    private static void validateId(final Integer id) throws Exception {
        if (id == null || id < 1) {
            throw new Exception("invalid id");
        }
    }

    public void create(final Integer id,
                       final String name,
                       final LocalDate birthday,
                       final Boolean sex,
                       final Float gpa,
                       final String grade) throws Exception {
        validateId(id);
        dataAccessLayer.create(new Student(id, name, birthday, sex, gpa, grade));
    }

    public void update(final Integer id,
                       final String name,
                       final LocalDate birthday,
                       final Boolean sex,
                       final Float gpa,
                       final String grade) throws Exception {
        validateId(id);
        dataAccessLayer.update(new Student(id, name, birthday, sex, gpa, grade));
    }

    public List<Student> getAll() {
        return dataAccessLayer.getAll();
    }

    public List<Student> searchByName(final String name) {
        return dataAccessLayer.searchByName(name);
    }

    public void delete(final Integer id) throws Exception {
        validateId(id);
        dataAccessLayer.delete(id);
    }
}
