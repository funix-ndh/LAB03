package asm5.crud.dataAccessLayer;

import java.util.List;

import asm5.crud.model.Student;

public interface DataAccessLayer {
    void create(Student student) throws Exception;

    void update(Student student) throws Exception;

    List<Student> getAll();

    List<Student> searchByName(String name);

    void delete(Integer id) throws Exception;
}
