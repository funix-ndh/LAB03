package asm5.crud.dataAccessLayer.impl;

import java.util.List;
import java.util.Optional;

import asm5.crud.dataAccessLayer.DataAccessLayer;
import asm5.crud.model.Student;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

public class DataAccessLayerImpl implements DataAccessLayer {
    private static List<Student> db;

    public DataAccessLayerImpl(final List<Student> db) {
        DataAccessLayerImpl.db = db;
    }

    @Override
    public void create(final Student student) throws Exception {
        final long count = db.stream().filter(s -> s.getId().equals(student.getId())).count();
        if (count > 0) {
            throw new Exception("id existed");
        }
        db.add(student);
    }

    @Override
    public void update(final Student student) throws Exception {
        final Optional<Student> foundStudent = db.stream().filter(s -> s.getId().equals(student.getId()))
                                                 .findFirst();
        if (!foundStudent.isPresent()) {
            throw new Exception("id not found");
        }
        foundStudent.get().setName(student.getName());
        foundStudent.get().setBirthday(student.getBirthday());
        foundStudent.get().setSex(student.getSex());
        foundStudent.get().setGpa(student.getGpa());
        foundStudent.get().setGrade(student.getGrade());
    }

    @Override
    public List<Student> getAll() {
        return db;
    }

    @Override
    public List<Student> searchByName(final String name) {
        throw new NotImplementedException();
    }

    @Override
    public void delete(final Integer id) throws Exception {
        final Optional<Student> student = db.stream().filter(s -> s.getId().equals(id)).findFirst();
        if (!student.isPresent()) {
            throw new Exception("id not found");
        }
        db.remove(student.get());
    }
}
