package test.emailcheck;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import asm5.emailcheck.EmailCheck;

@RunWith(Parameterized.class)
public class EmailCheckTest {

    private EmailCheck emailCheck;

    @Parameter
    public String msg;
    @Parameter(1)
    public String input;
    @Parameter(2)
    public Boolean expected;

    @Parameters(name = "{index}: {0}, input={1}, expected is:{2} ")
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][] {
                { "Valid email", "email@domain.com", true },
                { "Email contains dot in the address field", "firstname.lastname@domain.com", true },
                { "Email contains dot with subdomain", "email@subdomain.domain.com", true },
                { "Plus sign is considered valid character", "firstname+lastname@domain.com", true },
                { "Domain is valid IP address", "email@123.123.123.123", true },
                { "Square bracket around IP address is considered valid", "email@[123.123.123.123]", true },
                { "Quotes around email is considered valid", "\"email\"@domain.com", true },
                { "Digits in address are valid", "1234567890@domain.com", true },
                { "Dash in domain name is valid", "email@domain-one.com", true },
                { "Underscore in the address field is valid", "_______@domain.com", true },
                { ".name is valid Top Level Domain name", "email@domain.name", true },
                {
                        "Dot in Top Level Domain name also considered valid (use co.jp as example here)",
                        "email@domain.co.jp", true
                },
                { "Dash in address field is valid", "firstname-lastname@domain.com", true },
                { "Missing @ sign and domain", "plainaddress", false },
                { "Garbage", "#@%^%#$@#$@#.com", false },
                { "Missing username", "@domain.com", false },
                { "Encoded html within email is invalid", "Joe Smith <email@domain.com>", false },
                { "Missing @", "email.domain.com", false },
                { "Two @ sign", "email@domain@domain.com", false },
                { "Leading dot in address is not allowed", ".email@domain.com", false },
                { "Trailing dot in address is not allowed", "email.@domain.com", false },
                { "Multiple dots", "email..email@domain.com", false },
                { "Unicode char as address", "あいうえお@domain.com", false },
                { "Text followed email is not allowed", "email@domain.com (Joe Smith)", false },
                { "Missing top level domain (.com/.net/.org/etc)", "email@domain", false },
                { "Leading dash in front of domain is invalid", "email@-domain.com", false },
                { "Multiple dot in the domain portion is invalid", "email@domain..com", false }
        });
    }

    @Before
    public void initialize() {
        emailCheck = new EmailCheck();
    }

    @Test
    public void testIsValidEmailAddress_valid() {
        assertEquals(msg, expected, emailCheck.isValidEmailAddress(input));
    }
}
