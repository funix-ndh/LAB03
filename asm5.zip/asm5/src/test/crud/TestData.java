package test.crud;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import asm5.crud.dataAccessLayer.DataAccessLayer;
import asm5.crud.model.Student;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

public final class TestData {

    // TEST DATA
    public static final List<Student> data = Arrays.asList(
            new Student(1, "John", LocalDate.of(1981, 5, 25), true, 9.2f, "Xuất xắc"),
            new Student(2, "Scott", LocalDate.of(1990, 8, 5), true, 8.0f, "Giỏi"),
            new Student(3, "Marry", LocalDate.of(1991, 9, 11), true, 7.6f, "Khá"),
            new Student(4, "Richard", LocalDate.of(1992, 12, 19), true, 6.0f, "Trung Bình"),
            new Student(5, "Monica", LocalDate.of(1993, 5, 24), false, 7.9f, "Khá"),
            new Student(6, "Ted", LocalDate.of(1995, 4, 22), true, 5.3f, "Trung Bình"),
            new Student(7, "Tom", LocalDate.of(1998, 11, 15), true, 8.7f, "Giỏi"),
            new Student(8, "Bob", LocalDate.of(1997, 3, 5), true, 7.0f, "Khá"),
            new Student(9, "Nick", LocalDate.of(1980, 12, 8), true, 5.8f, "Trung Bình"),
            new Student(10, "Ryan", LocalDate.of(1991, 1, 11), true, 8.8f, "Giỏi")
    );

    private TestData() {}

    public static class StubDataAccessLayer implements DataAccessLayer {
        @Override
        public void create(Student student) throws Exception {
            throw new NotImplementedException();
        }

        @Override
        public void update(Student student) throws Exception {
            throw new NotImplementedException();
        }

        @Override
        public List<Student> getAll() {
            throw new NotImplementedException();
        }

        @Override
        public List<Student> searchByName(String name) {
            return Collections.singletonList(new Student(1, name, null, false, null, null));
        }

        @Override
        public void delete(Integer id) throws Exception {
            throw new NotImplementedException();
        }
    }
}
