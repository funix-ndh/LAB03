package test.crud;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import asm5.crud.businessLayer.BusinessLayer;
import asm5.crud.dataAccessLayer.impl.DataAccessLayerImpl;
import asm5.crud.model.Student;

public class CRUDTest {

    // TEST OBJECT
    private BusinessLayer businessLayer;

    // TEST DATA
    List<Student> db;
    Integer id;
    String name;
    LocalDate birthday;
    Boolean sex;
    Float gpa;
    String grade;

    @Before
    public void setup() {
        // re-initialize object every time run the test
        db = new ArrayList<>(TestData.data);
        businessLayer = new BusinessLayer(new DataAccessLayerImpl(db));

        // initialize data
        id = 11;
        name = "James";
        birthday = LocalDate.of(1997, 12, 01);
        sex = false;
        gpa = 3.5f;
        grade = "Good";
    }

    @Test
    public void testCRUD_addStudent_correct() throws Exception {
        businessLayer.create(id, name, birthday, sex, gpa, grade);

        final Student student = db.get(db.size() - 1); // get last data
        assertEquals(student.getId(), id);
        assertEquals(student.getName(), name);
        assertEquals(student.getBirthday(), birthday);
        assertEquals(student.getSex(), false);
        assertEquals(student.getGpa(), gpa);
        assertEquals(student.getGrade(), grade);
    }

    @Test(expected = Exception.class)
    public void testCRUD_addStudent_throwInvalidId() throws Exception {
        businessLayer.create(0, name, birthday, sex, gpa, grade);
    }

    @Test(expected = Exception.class)
    public void testCRUD_addStudent_throwDuplicatedId() throws Exception {
        businessLayer.create(1, name, birthday, sex, gpa, grade);
    }

    @Test
    public void testCRUD_updateStudent_correct() throws Exception {
        id = 1;
        businessLayer.update(id, name, birthday, sex, gpa, grade);

        final Student student = db.get(0); // get first data
        assertEquals(student.getId(), id);
        assertEquals(student.getName(), name);
        assertEquals(student.getBirthday(), birthday);
        assertEquals(student.getSex(), false);
        assertEquals(student.getGpa(), gpa);
        assertEquals(student.getGrade(), grade);
    }

    @Test(expected = Exception.class)
    public void testCRUD_updateStudent_throwInvalidId() throws Exception {
        businessLayer.update(0, name, birthday, sex, gpa, grade);
    }

    @Test(expected = Exception.class)
    public void testCRUD_updateStudent_throwNotExistedId() throws Exception {
        businessLayer.update(11, name, birthday, sex, gpa, grade);
    }

    @Test
    public void testCRUD_getAll_correct() throws Exception {
        assertArrayEquals(businessLayer.getAll().toArray(), db.toArray());
    }

    @Test
    public void testCRUD_deleteStudent_correct() throws Exception {
        businessLayer.delete(1);
        assertEquals(db.size(), TestData.data.size() - 1); // expect size should decrease by 1
        final Student student = db.get(0); // get first data
        assertEquals(student.getId(), Integer.valueOf(2));
    }

    @Test(expected = Exception.class)
    public void testCRUD_deleteStudent_throwInvalidId() throws Exception {
        businessLayer.delete(0);
    }

    @Test(expected = Exception.class)
    public void testCRUD_deleteStudent_throwNotExistedId() throws Exception {
        businessLayer.delete(11);
    }
}
