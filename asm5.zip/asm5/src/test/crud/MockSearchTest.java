package test.crud;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import asm5.crud.businessLayer.BusinessLayer;
import test.crud.TestData.StubDataAccessLayer;
import asm5.crud.model.Student;

public class MockSearchTest {
    private BusinessLayer businessLayer;

    @Before
    public void initialize() {
        businessLayer = new BusinessLayer(new StubDataAccessLayer());
    }

    @Test
    public void testSearchStudent_withMockDataAccessLayer() {
        final List<Student> list = businessLayer.searchByName("test");
        assertEquals(list.get(0).getName(), "test");
    }
}
