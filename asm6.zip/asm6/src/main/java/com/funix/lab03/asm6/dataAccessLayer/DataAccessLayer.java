package com.funix.lab03.asm6.dataAccessLayer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import com.funix.lab03.asm6.model.User;

@Service
public class DataAccessLayer {

    private final List<User> users;

    public DataAccessLayer() throws IOException {
        users = initialize();
    }

    private static List<User> initialize() throws IOException {
        try (final BufferedReader br = new BufferedReader(
                new InputStreamReader(new ClassPathResource("db/users.txt").getInputStream()))) {
            final List<User> users = new ArrayList<>();
            String line;
            for (line = br.readLine(); line != null; line = br.readLine()) {
                final String[] arrStr = line.split(",");
                final User user = new User(arrStr[0],
                                           arrStr[1],
                                           Integer.valueOf(arrStr[2]),
                                           Integer.valueOf(arrStr[3]));
                users.add(user);
            }
            return users;
        }
    }

    public Optional<User> getByUserName(final String username) {
        return users.stream()
                    .filter(u -> username.equals(u.getUsername())).findAny();
    }

    public void updateDb() throws IOException {
        try (final PrintWriter pw = new PrintWriter(new ClassPathResource("db/users.txt").getFile())) {
            for (final User user : users) {
                pw.append(user.toString());
            }
        }
    }
}
