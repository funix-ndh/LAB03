package com.funix.lab03.asm6.model;

public class AuthenticationInfo {
    private final String username;

    public AuthenticationInfo(final String username) {this.username = username;}

    public String getUsername() {
        return username;
    }
}
