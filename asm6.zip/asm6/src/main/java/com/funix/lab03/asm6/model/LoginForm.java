package com.funix.lab03.asm6.model;

public class LoginForm {
    private String username;
    private String password;
    private String errorUsername;
    private String errorPassword;
    private String otherErrorMsg;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getErrorUsername() {
        return errorUsername;
    }

    public void setErrorUsername(String errorUsername) {
        this.errorUsername = errorUsername;
    }

    public String getErrorPassword() {
        return errorPassword;
    }

    public void setErrorPassword(String errorPassword) {
        this.errorPassword = errorPassword;
    }

    public String getOtherErrorMsg() {
        return otherErrorMsg;
    }

    public void setOtherErrorMsg(String otherErrorMsg) {
        this.otherErrorMsg = otherErrorMsg;
    }
}
