package com.funix.lab03.asm6.controller;

import java.io.IOException;
import java.util.Optional;

import org.springframework.stereotype.Controller;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.funix.lab03.asm6.dataAccessLayer.DataAccessLayer;
import com.funix.lab03.asm6.model.AuthenticationInfo;
import com.funix.lab03.asm6.model.ConfirmAccountForm;
import com.funix.lab03.asm6.model.LoginForm;
import com.funix.lab03.asm6.model.User;

@Controller
@SessionAttributes("authenticationInfo")
public class LoginController {

    final DataAccessLayer dataAccessLayer;

    public LoginController(final DataAccessLayer dataAccessLayer) {
        this.dataAccessLayer = dataAccessLayer;
    }

    @GetMapping("/login")
    public ModelAndView login() {
        return loginView(new LoginForm());
    }

    @PostMapping("/login")
    public ModelAndView login(final LoginForm loginForm) throws IOException {

        // validate form
        if (!isValidForm(loginForm)) {
            return loginView(loginForm);
        }

        // get user
        final Optional<User> optionalUser = dataAccessLayer.getByUserName(loginForm.getUsername());

        // not found user
        if (!optionalUser.isPresent()) {
            loginForm.setOtherErrorMsg("Invalid User ID/Password");
            return loginView(loginForm);
        }

        // found user
        final User user = optionalUser.get();

        // check password
        if (!user.getPassword().equals(hashPwd(loginForm.getPassword()))) {

            // check exceed login fail
            if (user.getRemain() == 1) {
                loginForm.setOtherErrorMsg("Fail attempts exceed 3 times, account is locked");
                return loginView(loginForm);
            }

            // show invalid account/password
            user.setRemain(user.getRemain() - 1);
            loginForm.setOtherErrorMsg(String.format(
                    "Invalid User ID/Password. Number of attempts left %d", user.getRemain()));
            return loginView(loginForm);
        }

        // is first time
        if (user.getLoginCountTimes() == 0) {
            return confirmAccountView(new AuthenticationInfo(loginForm.getUsername()),
                                      new ConfirmAccountForm());
        }
        return dashboardView();
    }

    @PostMapping("/confirm-account")
    public ModelAndView confirmAccount(@ModelAttribute final AuthenticationInfo authenticationInfo,
                                       final ConfirmAccountForm confirmAccountForm) throws Exception {
        final String answer1 = confirmAccountForm.getAnswer1();
        final String answer2 = confirmAccountForm.getAnswer2();
        final String answer3 = confirmAccountForm.getAnswer3();
        if (answer1.isEmpty() && answer2.isEmpty() && answer3.isEmpty()) {
            confirmAccountForm.setErrorMsg("answer at least 1 question");
            return confirmAccountView(authenticationInfo, confirmAccountForm);
        }

        final String oldPwd = confirmAccountForm.getOldPassword();
        final String newPwd = confirmAccountForm.getNewPassword();
        final String confirmPwd = confirmAccountForm.getConfirmPassword();

        if (!confirmPwd.equals(newPwd)) {
            confirmAccountForm.setErrorMsg("confirm password doesn't match");
            return confirmAccountView(authenticationInfo, confirmAccountForm);
        }

        final User user = dataAccessLayer.getByUserName(authenticationInfo.getUsername())
                                         .orElseThrow(() -> new Exception("invalid authentication"));

        if (!user.getPassword().equals(hashPwd(oldPwd))) {
            confirmAccountForm.setErrorMsg("wrong old password");
            return confirmAccountView(authenticationInfo, confirmAccountForm);
        }
        user.setPassword(hashPwd(newPwd));
        user.setLoginCountTimes(user.getLoginCountTimes() + 1);
        return new ModelAndView("redirect:/login");
    }

    private static String hashPwd(String oldPwd) {
        return DigestUtils.md5DigestAsHex(oldPwd.getBytes()).toUpperCase();
    }

    private static ModelAndView loginView(final LoginForm loginForm) {
        return new ModelAndView("login", "loginForm", loginForm);
    }

    private static ModelAndView confirmAccountView(final AuthenticationInfo authenticationInfo,
                                                   final ConfirmAccountForm confirmAccountForm) {
        final ModelAndView model = new ModelAndView("confirmAccount");
        model.addObject("authenticationInfo", authenticationInfo);
        model.addObject("confirmAccountForm", confirmAccountForm);
        return model;
    }

    private static ModelAndView dashboardView() {
        return new ModelAndView("redirect:/dashboard");
    }

    private static boolean isValidForm(final LoginForm loginForm) {
        final String username = loginForm.getUsername();
        final String password = loginForm.getPassword();
        boolean valid = true;
        if (username.length() < 1 || username.length() > 16) {
            loginForm.setErrorUsername("(max 16 characters)");
            valid = false;
        }
        if (password.length() < 1 || password.length() > 8) {
            loginForm.setErrorPassword("(max 8 characters)");
            valid = false;
        }
        return valid;
    }
}
