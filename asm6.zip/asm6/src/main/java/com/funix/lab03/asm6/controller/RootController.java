package com.funix.lab03.asm6.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.funix.lab03.asm6.model.AuthenticationInfo;

@Controller
@RequestMapping("/")
@SessionAttributes("authenticationInfo")
public class RootController {

    @GetMapping
    public ModelAndView index() {
        return new ModelAndView("redirect:/login");
    }


    @GetMapping("/dashboard")
    public ModelAndView dashboard(@ModelAttribute final AuthenticationInfo authenticationInfo) {
        return new ModelAndView("dashboard", "authenticationInfo", authenticationInfo);
    }
}
