package com.funix.lab03.asm6.model;

public class User {
    private String username;
    private String password;
    private Integer remain;
    private Integer loginCountTimes;

    public User(String username, String password, Integer remain, Integer loginCountTimes) {
        this.username = username;
        this.password = password;
        this.remain = remain;
        this.loginCountTimes = loginCountTimes;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getRemain() {
        return remain;
    }

    public void setRemain(Integer remain) {
        this.remain = remain;
    }

    public Integer getLoginCountTimes() {
        return loginCountTimes;
    }

    public void setLoginCountTimes(Integer loginCountTimes) {
        this.loginCountTimes = loginCountTimes;
    }

    @Override
    public String toString() {
        return String.format("%s,%s,%s,%s", username, password, remain, loginCountTimes);
    }
}
