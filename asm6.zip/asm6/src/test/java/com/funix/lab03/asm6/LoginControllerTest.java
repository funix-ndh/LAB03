package com.funix.lab03.asm6;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.servlet.ModelAndView;

import com.funix.lab03.asm6.controller.LoginController;
import com.funix.lab03.asm6.model.AuthenticationInfo;
import com.funix.lab03.asm6.model.ConfirmAccountForm;
import com.funix.lab03.asm6.model.LoginForm;

@SpringBootTest
public class LoginControllerTest {

    @Autowired
    private LoginController loginController;

    @Test
    public void testLogin_Get() {
        final ModelAndView expected = new ModelAndView("login", "loginForm", new LoginForm());
        assertThat(loginController.login()).usingRecursiveComparison().isEqualTo(expected);
    }

    @Test
    public void testLogin_Post_Validate() throws IOException {
        final LoginForm model = new LoginForm();
        model.setUsername("over 16 chars - over 16 chars");
        model.setPassword("over 8 chars - over 8 chars");
        final LoginForm actual = (LoginForm) loginController.login(model).getModel().get("loginForm");
        assertThat(actual.getErrorUsername()).isNotEmpty();
        assertThat(actual.getErrorPassword()).isNotEmpty();
    }

    @Test
    public void testLogin_Post_Fail_NotExisted() throws IOException {
        final LoginForm model = new LoginForm();
        model.setUsername("1");
        model.setPassword("2");
        final LoginForm actual = (LoginForm) loginController.login(model).getModel().get("loginForm");
        assertThat(actual.getOtherErrorMsg()).isNotEmpty();
    }

    @Test
    public void testLogin_Post_Fail_WrongPasswordNotExceed() throws IOException {
        final LoginForm model = new LoginForm();
        model.setUsername("admin01");
        model.setPassword("2");
        final LoginForm actual = (LoginForm) loginController.login(model).getModel().get("loginForm");
        assertThat(actual.getOtherErrorMsg()).isNotEmpty();
    }

    @Test
    public void testLogin_Post_Fail_WrongPasswordExceed() throws IOException {
        final LoginForm model = new LoginForm();
        model.setUsername("admin01");
        model.setPassword("2");
        loginController.login(model);
        loginController.login(model);
        final LoginForm actual = (LoginForm) loginController.login(model).getModel().get("loginForm");
        assertThat(actual.getOtherErrorMsg()).isNotEmpty();
    }

    @Test
    public void testLogin_Post_OK_FirstTime() throws IOException {
        final ModelAndView expected = new ModelAndView("confirmAccount");
        expected.addObject("authenticationInfo", new AuthenticationInfo("admin01"));
        expected.addObject("confirmAccountForm", new ConfirmAccountForm());

        final LoginForm model = new LoginForm();
        model.setUsername("admin01");
        model.setPassword("123456");
        assertThat(loginController.login(model))
                .usingRecursiveComparison()
                .isEqualTo(expected);
    }

    @Test
    public void testLogin_Post_OK_NotFirstTime() throws IOException {
        final LoginForm model = new LoginForm();
        model.setUsername("admin03");
        model.setPassword("123456");
        assertThat(loginController.login(model))
                .usingRecursiveComparison()
                .isEqualTo(new ModelAndView("redirect:/dashboard"));
    }

    @Test
    public void testConfirmAccount_Validate_AtLeastOneAnswer() throws Exception {
        final AuthenticationInfo fakeAuthInfo = new AuthenticationInfo("test");
        final ConfirmAccountForm form = new ConfirmAccountForm();
        form.setAnswer1("");
        form.setAnswer2("");
        form.setAnswer3("");

        final ModelAndView actualMAV = loginController.confirmAccount(fakeAuthInfo, form);
        final ConfirmAccountForm actual = (ConfirmAccountForm) actualMAV.getModel().get("confirmAccountForm");

        assertThat(actualMAV.getViewName()).isEqualTo("confirmAccount");
        assertThat(actual.getErrorMsg()).isNotEmpty();
    }

    @Test
    public void testConfirmAccount_Validate_PasswordMatch() throws Exception {
        final AuthenticationInfo fakeAuthInfo = new AuthenticationInfo("test");
        final ConfirmAccountForm form = new ConfirmAccountForm();
        form.setAnswer1("not empty");
        form.setOldPassword("1");
        form.setNewPassword("2");
        form.setConfirmPassword("3");

        final ModelAndView actualMAV = loginController.confirmAccount(fakeAuthInfo, form);
        final ConfirmAccountForm actual = (ConfirmAccountForm) actualMAV.getModel().get("confirmAccountForm");

        assertThat(actualMAV.getViewName()).isEqualTo("confirmAccount");
        assertThat(actual.getErrorMsg()).isNotEmpty();
    }

    @Test
    public void testConfirmAccount_Validate_WrongPassword() throws Exception {
        final AuthenticationInfo fakeAuthInfo = new AuthenticationInfo("admin01");
        final ConfirmAccountForm form = new ConfirmAccountForm();
        form.setAnswer1("not empty");
        form.setOldPassword("1");
        form.setNewPassword("2");
        form.setConfirmPassword("2");

        final ModelAndView actualMAV = loginController.confirmAccount(fakeAuthInfo, form);
        final ConfirmAccountForm actual = (ConfirmAccountForm) actualMAV.getModel().get("confirmAccountForm");

        assertThat(actualMAV.getViewName()).isEqualTo("confirmAccount");
        assertThat(actual.getErrorMsg()).isNotEmpty();
    }

    @Test
    public void testConfirmAccount_Validate_Success() throws Exception {
        final AuthenticationInfo fakeAuthInfo = new AuthenticationInfo("admin01");
        final ConfirmAccountForm form = new ConfirmAccountForm();
        form.setAnswer1("not empty");
        form.setOldPassword("123456");
        form.setNewPassword("2");
        form.setConfirmPassword("2");

        assertThat(loginController.confirmAccount(fakeAuthInfo, form))
                .usingRecursiveComparison()
                .isEqualTo(new ModelAndView("redirect:/login"));
    }
}
